#!/bin/bash
set -e

# Update package lists
sudo apt-get update -y

# Install necessary tools
sudo apt-get install -y unzip wget
#!/bin/bash
set -euo pipefail

# 1. 更新系统并安装必要软件
sudo apt-get update -y
sudo apt-get install -y python3 python3-venv python3-pip unzip awscli

# 2. 下载 webapp.zip (假设你在 S3 中已放好)
aws s3 cp s3://bigdata-project1-storage/webapp.zip /tmp/webapp.zip

# 3. 创建 /opt/myapp 目录，并解压项目到这里
sudo mkdir -p /opt/myapp
sudo chown ubuntu:ubuntu /opt/myapp  # 假设默认用户名 ubuntu
cd /opt/myapp
unzip -o /tmp/webapp.zip

# 4. 创建虚拟环境并安装依赖
python3 -m venv venv
source venv/bin/activate

# 如果你有 requirements.txt，就安装
if [ -f "/opt/myapp/requirements.txt" ]; then
    pip install -r requirements.txt
fi

